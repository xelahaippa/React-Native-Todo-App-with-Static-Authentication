

export const GET_NAME = 'GET_NAME';
export const UPDATE_TODO = 'UPDATE_TODO';
